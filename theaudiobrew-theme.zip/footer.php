</div>
<?php wp_footer(); ?>
<script type="text/javascript" src="//downloads.mailchimp.com/js/signup-forms/popup/unique-methods/embed.js" data-dojo-config="usePlainJson: true, isDebug: false"></script><script type="text/javascript">window.dojoRequire(["mojo/signup-forms/Loader"], function(L) { L.start({"baseUrl":"mc.us5.list-manage.com","uuid":"7bb602a8f97ed4dd8480fd55c","lid":"9b705cfd75","uniqueMethods":true}) })</script>
</body>
</html>
