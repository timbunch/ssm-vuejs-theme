<?php
global $post;
get_header();
?>
    <wrapper style="z-index: 2; position: relative;">
		<?php if (have_posts()) :
			while (have_posts()) : the_post(); ?>

                <div style="height:2000px;"></div>
				<?php the_title('<h1>', '</h1>'); ?>
				<?php the_content($post->ID); ?>
			<?php
			endwhile;
		endif;
		?>
    </wrapper>
<?php get_footer();
