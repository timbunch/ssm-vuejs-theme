<?php

function tab_enqueue_scripts()
{
    if (!is_page('manager')) {
		$src = 'https://s3-us-west-2.amazonaws.com/theaudiobrew.com/dist/app.js';
		$server_name = $_SERVER["SERVER_NAME"];
		if ($server_name === 'localhost') {
			$src = '/wp-content/themes/theaudiobrew-theme/dist/app.js';
		}
		wp_enqueue_script( 'tab-scripts', $src, false, '20191120', true);
    }
}

add_action( 'wp_enqueue_scripts', 'tab_enqueue_scripts');
