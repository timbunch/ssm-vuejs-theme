<?php

function tab_enqueue_styles()
{
    if (!is_page('manager')) {
		$src = 'https://s3-us-west-2.amazonaws.com/theaudiobrew.com/dist/app.css';
		$server_name = $_SERVER["SERVER_NAME"];
		if ($server_name === 'localhost') {
			$src = '/wp-content/themes/theaudiobrew-theme/dist/app.css';
		}
        wp_enqueue_style('tab-styles', $src, false, '');
        wp_enqueue_style('tab-google-fonts', 'https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons|Lobster', false, '');
    }
}

add_action('wp_enqueue_scripts', 'tab_enqueue_styles', 10);
