<?php

add_filter('the_content', 'remove_empty_tags', 99);

function remove_empty_tags($content)
{
	$pattern = "/<p[^>]*><\\/p[^>]*>/";
	$content = str_replace('&nbsp;', '', $content);
	$content = str_replace(['http://localhost:8000/wp-content/uploads', 'http://localhost:8000/uploads'], '//theaudiobrew-uploads.s3-us-west-2.amazonaws.com/uploads', $content);
	return preg_replace($pattern, '', trim($content));
}
