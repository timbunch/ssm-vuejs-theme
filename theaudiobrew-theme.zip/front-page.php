<?php get_header(); ?>
    <wrapper>
        <div style="height:2000px;"></div>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php the_title('<h1>', '</h1>'); ?>
			<?php the_content(); ?>
		<?php endwhile; endif;
		$api = new The_Audio_Brew_Deals_Api();
		$posts = $api->query_home_deals();
		foreach ($posts as $post) :
			echo PHP_EOL . '<div>' . PHP_EOL;
			echo '<h2>' . $post['headline'] . '</h2>' . PHP_EOL;
			echo '<p>' . $post['excerpt'] . '</p>' . PHP_EOL;
			echo "<a href='/deal/{$post['slug']}'>Learn More...</a>";
			echo '</div>' . PHP_EOL;
		endforeach;
		?>
    </wrapper>
<?php get_footer();
