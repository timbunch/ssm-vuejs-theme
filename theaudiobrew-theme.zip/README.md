# theaudiobrew-theme
The Audio Brew WP Theme

## JS, CSS Deployment

`npm run production`

This will run a production build and the following additional commands:

`aws s3 cp /Volumes/FAST_STORAGE/github/theaudiobrew-theme/dist/ s3://theaudiobrew.com/dist --recursive` 

`aws cloudfront create-invalidation --distribution-id E1HJ1BFRE6RB9V --paths /dist/app.js`
`aws cloudfront create-invalidation --distribution-id E1HJ1BFRE6RB9V --paths /dist/app.css`

## Invalidate JSON/API

`aws cloudfront create-invalidation --distribution-id E1HJ1BFRE6RB9V --paths /wp-json`

##### release notes:
